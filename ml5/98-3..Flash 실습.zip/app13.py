# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습13

# 전체 코드
# http://127.0.0.1:5000/
# http://127.0.0.1:5000/html
# http://127.0.0.1:5000/css
# http://127.0.0.1:5000/javascript
# http://127.0.0.1:5000/stars/6
# http://127.0.0.1:5000/movies/2
# http://127.0.0.1:5000/daum
# http://127.0.0.1:5000/login
# http://127.0.0.1:5000/create
# http://127.0.0.1:5000/<C++>/delete



import os
from flask import Flask, abort, render_template, redirect, request, session

app = Flask(__name__, template_folder='templates')
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

app.secret_key = 'kt2021'

members = [
       {'id': 'test1', 'pw': '123456', 'name': '이숙번'},
       {'id': 'test2', 'pw': '123456', 'name': '이고잉'}
]


def get_menu():
    menus = [f'<li><a href="/{file}/">{file.upper()}</a></li>' 
             for file in os.listdir('content1') if '.' not in file]
    return '\n'.join(menus)

@app.route('/')
def index():
#     return get_template('index.html').format(menu=get_menu())
    return render_template('index6.html', menu=get_menu(), user=session.get('user'))

@app.route('/login', methods=['get', 'post'])
def login():
    if request.method == 'GET':
        return render_template('login.html', menu=get_menu())
    
    # 로그인 확인
    userid = request.form.get('userid')
    password = request.form.get('password')
    
    users = [m for m in members if m['id'] == userid and m['pw'] == password]
    if len(users) == 0:
        # return '로그인 실패'
        return render_template('login.html', menu=get_menu(), msg='로그인에 실패했습니다.')
    else:
        # '로그인 성공'
        session['user'] = users[0]
        return redirect('/')

@app.route('/logout')
def logout():
    session.pop('user')
    # delete session['user']
    return redirect('/')

@app.route('/<title>')
@app.route('/<title>/')
def page(title):
    if not os.path.isfile(f'content1/{title}'):
        return abort(404)
        
    with open(f'content1/{title}', 'r', encoding='utf8') as f:
        content = f.read()
#     return get_template('template.html').format(title=title, content=content, menu=get_menu())
    return render_template('template6.html', title=title, content=content, menu=get_menu(), user=session.get('user'))

@app.route('/stars/<num>')
def stars(num):
    stars = ["*" * (i + 1) for i in range(int(num))]
    return "<br>".join(stars)

@app.route('/<title>/delete')
def delete(title):
    os.remove(f'content1/{title}')
    return redirect('/')

@app.route('/create', methods=['get', 'post'])
def create():
    if request.method == 'GET':
        return render_template('create.html', menu=get_menu())
    
    # 파일 생성
    title = request.form.get('title')
    content = request.form.get('content')
    with open(f'content1/{title}', 'w', encoding='utf8') as f:
        f.write(content)
    
    return redirect(f'/{title}')

@app.route('/daum')
@app.route('/daum/')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text

@app.route('/movies/<num>')
def movies(num):
    import re, requests, bs4, datetime

    def get_movies(week_date=''):
        url = 'https://movie.daum.net/boxoffice/weekly'
        query = {'startDate': week_date}
        res = requests.get(url, params=query)
        soup = bs4.BeautifulSoup(res.content, 'html.parser')

        movies = []
        for tag in soup.select('.list_movieranking > li')[:14]:
            title = tag.strong.a.get_text()
            rank = tag.select('.rank_num')[0].text
            open_day = tag.select('.txt_num')[0].text
            attendance = tag.select('.info_txt')[1].text
            attendance = re.sub(r'[^0-9]','',attendance)

            #print(title, rank, open_day, attendance)

            getter = dict(title = title, 
                          rank = rank,
                          open_day = open_day,
                          attendance = attendance
                         )
            movies.append(getter)

        return movies
    
    weeks = [datetime.date.today() - datetime.timedelta(days=i*7) 
             for i in range(int(num))]
    weeks_best = [get_movies(w.strftime('%Y%m%d')) for w in weeks]

    return render_template('movies.html', weeks_best=weeks_best)


if __name__ == '__main__':
    app.run()