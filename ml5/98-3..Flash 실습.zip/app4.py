# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습4
# http://localhost:5000/  

# get_template 함수의 이용


from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/daum')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text
    
def get_template(filename):
    with open(f'views/{filename}', 'r', encoding='utf-8') as f:
        template = f.read()
    return template
    
@app.route('/')
def index():
    return get_template('index.html')

@app.route('/html/')
def html():
    return get_template('1.html')

@app.route('/css/')
def css():
    return get_template('2.html')

@app.route('/javascript/')
def javascript():
    return get_template('3.html')

if __name__ == '__main__':
    app.run()