# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습2
# http://localhost:5000/  접속
# http://localhost:5000/html/, http://localhost:5000/css, http://localhost:5000/javascript 접속
# http://localhost:5000/daum 접속


#template.html 내용
'''
<!doctype html>
<html>
<head>
  <title>WEB1 - {0}</title>
  <meta charset="utf-8">
</head>
<body>
  <h1><a href="/">WEB</a></h1>
  <ol>
    <li><a href="/html/">HTML</a></li>
    <li><a href="/css/">CSS</a></li>
    <li><a href="/javascript/">JavaScript</a></li>
  </ol>
  <h2>{0}</h2>
  <p>{1}</p>
</body>
</html>
'''



from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/daum')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text
    
@app.route('/')
def hello_world():
    with open('template.html', 'r', encoding='utf-8') as f:
        template = f.read()
    return template.format('Welcome', '''The World Wide Web (abbreviated WWW or the Web) is an information space where documents and other web resources are identified by Uniform Resource Locators (URLs), interlinked by hypertext links, and can be accessed via the Internet.[1] English scientist Tim Berners-Lee invented the World Wide Web in 1989. He wrote the first web browser computer program in 1990 while employed at CERN in Switzerland.[2][3] The Web browser was released outside of CERN in 1991, first to other research institutions starting in January 1991 and to the general public on the Internet in August 1991.''')

@app.route('/html/')
def html():
    with open('template.html', 'r', encoding='utf-8') as f:
        template = f.read()
    return template.format('Html', '''Hypertext Markup Language (HTML)</a> is the standard markup language for <strong>creating <u>web</u> pages</strong> and web applications.Web browsers receive HTML documents from a web server or from local storage and render them into multimedia web pages. HTML describes the structure of a web page semantically and originally included cues for the appearance of the document.''')

@app.route('/css/')
def css():
    with open('template.html', 'r', encoding='utf-8') as f:
        template = f.read()
    return template.format('css', '''Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language. Although most often used to set the visual style of web pages and user interfaces written in HTML and XHTML, the language can be applied to any XML document, including plain XML, SVG and XUL, and is applicable to rendering in speech, or on other media. Along with HTML and JavaScript, CSS is a cornerstone technology used by most websites to create visually engaging webpages, user interfaces for web applications, and user interfaces for many mobile applications.''')

@app.route('/javascript/')
def javascript():
    with open('template.html', 'r', encoding='utf-8') as f:
        template = f.read()
    return template.format('javascript', '''JavaScript (/ˈdʒɑːvəˌskrɪpt/[6]), often abbreviated as JS, is a high-level, dynamic, weakly typed, prototype-based, multi-paradigm, and interpreted programming language. Alongside HTML and CSS, JavaScript is one of the three core technologies of World Wide Web content production. It is used to make webpages interactive and provide online programs, including video games. The majority of websites employ it, and all modern web browsers support it without the need for plug-ins by means of a built-in JavaScript engine. Each of the many JavaScript engines represent a different implementation of JavaScript, all based on the ECMAScript specification, with some engines not supporting the spec fully, and with many engines supporting additional features beyond ECMA.''')


if __name__ == '__main__':
    app.run()
    
