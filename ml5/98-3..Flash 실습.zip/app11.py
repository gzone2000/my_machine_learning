# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습11
# 로그인
# http://127.0.0.1:5000/login


import os
from flask import Flask, abort, render_template, redirect, request

app = Flask(__name__, template_folder='templates')
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

members = [
       {'id': 'test1', 'pw': '123456', 'name': '이숙번'},
       {'id': 'test2', 'pw': '123456', 'name': '이고잉'}
]

def get_menu():
    menus = [f'<li><a href="/{file}/">{file.upper()}</a></li>' 
             for file in os.listdir('content1') if '.' not in file]
    return '\n'.join(menus)

@app.route('/')
def index():
#     return get_template('index.html').format(menu=get_menu())
    return render_template('index5.html', menu=get_menu())

@app.route('/login', methods=['get', 'post'])
def login():
    if request.method == 'GET':
        return render_template('login.html', menu=get_menu())
    
    # 로그인 확인
    userid = request.form.get('userid')
    password = request.form.get('password')
    
    users = [m for m in members if m['id'] == userid and m['pw'] == password]
    if len(users) == 0:
        # return '로그인 실패'
        return render_template('login.html', menu=get_menu(), msg='로그인에 실패했습니다.')
    else:
        # '로그인 성공'
        return redirect('/')
        
if __name__ == '__main__':
    app.run()