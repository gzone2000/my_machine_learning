# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습14
# API

# http://127.0.0.1:5000/api/content
# http://127.0.0.1:5000/api/content/html



import os
from flask import Flask, abort, render_template, redirect, request, session, jsonify

app = Flask(__name__, template_folder='templates')
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route("/api/content", methods=['get', 'post'])
def content_list():
    if request.method == 'GET':
        contents = []
        for title in os.listdir('content1'):
            if '.' in title:
                continue 

            with open(f'content1/{title}', 'r', encoding='utf8') as f:
                contents.append({
                    'title': title,
                    'content': f.read()
                })

        return jsonify(contents)
    
    elif request.method == 'POST':
        # 생성
        title = request.form.get('title').strip()
        content = request.form.get('content').strip()
        with open(f'content1/{title}', 'w', encoding='utf8') as f:
            f.write(content)
            
        return jsonify({'success': True})
    
    return abort(405)


@app.route('/api/content/<title>', methods=['get', 'put', 'delete'])
def content(title):
    if request.method == 'GET':
        if not os.path.isfile(f"./content1/{title}"):
            return abort(404)

        with open(f"./content1/{title}", 'r', encoding="utf8") as f:
            result = dict(title=title, content=f.read())

        return jsonify(result)
    
    elif request.method == 'PUT':
        if not os.path.isfile(f"./content1/{title}"):
            return abort(404)
            
        newtitle = request.form.get('title')
        if newtitle != title:
            os.remove(f'./content1/{title}')

        with open(f'./content/{newtitle}', 'w', encoding='utf8') as f:
            f.write(request.form.get('content'))
        
        return jsonify({"success": True})
   

if __name__ == '__main__':
    app.run()