# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습8
# http://localhost:5000/  
# 1. index1.html, template2.html 파일을 views 폴더에 복사해 놓아야 함
# 2. 그리고 미리 template2.html 파일 웹브라우져에서 미리 보고 포맷이 어떻게 되어 있는지 확인

# 파일 내용을 읽어 변수의 내용을 채우는 대신에 render_template 사용하여 변수에 해댱하는 내용을 바로 채워보자
# Flask 프레임워크는 Jinja2 템플릿엔진을 기본으로 사용한다.
# Jinja2를 사용하면 render_template() 함수를 이용하여 HTML을 렌더링할수 있다.
# 이를 위해 tempates 폴더 밑에 템플릿 파일 즉, 아래 예제의 경우 index5.html, template5.html을 넣어 놓아야 함.
# 단, render_template 사용할 경우 변수 지정시 {{ title }} 이런식으로 괄호를 2개로 해야 함
# 그리고 Flask 생성시 template_folder 옵션을 지정 가능함

# 미리 tempates 폴더 아래 index5.html 파일 웹브라우져에서 열어보자.
# {{ menu | safe }} 보이는데 , {{ menu }} 으로 바꿔 테스트 해보자.
# safe 옵션이 없으면 html 의 특정 태그 (< > )등을 &lt 변경해서 태그 효력을 없앰



from flask import Flask, abort, render_template


# template_folder='' 옵션을 지정하지 않으면 기본은 templates 폴더가 됨.
app = Flask(__name__, template_folder='templates')
app.config['ENV'] = 'development'
app.config['DEBUG'] = True
    
    
# def get_template(filename):
#     with open(f'views/{filename}', 'r', encoding='utf-8') as f:
#         template = f.read()
#     return template
    
def get_menu():
    import os
    menus = [f'<li><a href="/{file}/">{file.upper()}</a></li>' 
             for file in os.listdir('content1') if '.' not in file]
    return '\n'.join(menus)
    
@app.route('/')
def index():
#     return get_template('index.html').format(menu=get_menu())
    return render_template("index5.html", menu=get_menu())
    

@app.route('/<title>')
@app.route('/<title>/')
def page(title):
    import os
    if not os.path.isfile(f'content1/{title}'):
        return abort(404)
        
    with open(f'content1/{title}', 'r', encoding='utf8') as f:
        content = f.read()
#     return get_template('template.html').format(title=title, content=content, menu=get_menu())
    return render_template("template5.html", title=title, content=content, menu=get_menu())

@app.route('/stars/<num>')
def stars(num):
    stars = ["*" * (i + 1) for i in range(int(num))]
    return "<br>".join(stars)

@app.route('/daum')
@app.route('/daum/')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text


if __name__ == '__main__':
    app.run()