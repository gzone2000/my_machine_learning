# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습5
# template.html 파일을 views 폴더에 미리 복사해 놓아야 함.
# 그리고 미리 template.html 파일 웹브라우져에서 미리 보고 포맷이 어떻게 되어 있는지 확인

# http://localhost:5000/  

# template & 변수 활용하여 url path 지정
# route에 변수를 지정하여 넘겨 줄수 있음 : '/<title>' , '/stars/<num>'


from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/daum')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text
    
def get_template(filename):
    with open(f'views/{filename}', 'r', encoding='utf-8') as f:
        template = f.read()
    return template
    
@app.route('/')
def index():
    return get_template('index.html')

contents = {
    'html': 'html is ...',
    'css': 'css is ...',
    'javascript': 'javascript is ...'
}


#  /<title> 와 /<title>/ 다르며 주의해야 함
@app.route('/<title>/')
def page(title):
    return get_template('template.html').format(title, contents.get(title))

# @app.route('/html/')
# def html():
#     return get_template('template.html').format('html', 'html is ...')

# @app.route('/css/')
# def css():
#     return get_template('template.html').format('css', 'css is ...')

# @app.route('/javascript/')
# def javascript():
#     return get_template('template.html').format('javascript', 'javascript is ...')


@app.route('/stars/<num>')
def stars(num):
    stars = ["*" * (i + 1) for i in range(int(num))]
    return "<br>".join(stars)

if __name__ == '__main__':
    app.run()