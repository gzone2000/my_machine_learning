# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습3
# views 폴더 만든후 index.html, 1.html, 2.html, 3.html 복사

# http://localhost:5000/  

from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/daum')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text
    
@app.route('/')
def index():
    with open('views/index.html', 'r', encoding='utf-8') as f:
        index = f.read()
    return index

@app.route('/html/')
def html():
    with open('views/1.html', 'r', encoding='utf-8') as f:
        html = f.read()
    return html

@app.route('/css/')
def css():
    with open('views/2.html', 'r', encoding='utf-8') as f:
        css = f.read()
    return css

@app.route('/javascript/')
def javascript():
    with open('views/3.html', 'r', encoding='utf-8') as f:
        javascript = f.read()
    return javascript

if __name__ == '__main__':
    app.run()