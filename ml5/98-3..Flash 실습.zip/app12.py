# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습12
# 세션은 여러분을 위해 쿠키 위에서 구현되어 지고 암호화를 사용하여 그 쿠키를 서명한다. 
# 즉, 사용자는 쿠키의 내용을 볼 수는 있지만 서명을 위해 사용된 비밀키를 알지 못한다면 쿠키의 내용을 변경할 수 없다는 것을 의미한다.
# 세션을 사용하기 위해서는 비밀키를 설정해야 한다.

# 세션과 로그인, 로그아웃
# http://127.0.0.1:5000/
# http://127.0.0.1:5000/login


import os
from flask import Flask, abort, render_template, redirect, request, session

app = Flask(__name__, template_folder='templates')
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

app.secret_key = 'kt2021'

members = [
       {'id': 'test1', 'pw': '123456', 'name': '이숙번'},
       {'id': 'test2', 'pw': '123456', 'name': '이고잉'}
]

def get_menu():
    menus = [f'<li><a href="/{file}/">{file.upper()}</a></li>' 
             for file in os.listdir('content1') if '.' not in file]
    return '\n'.join(menus)

@app.route('/')
def index():
#     return get_template('index.html').format(menu=get_menu())
    return render_template('index6.html', menu=get_menu(), user=session.get('user'))

@app.route('/login', methods=['get', 'post'])
def login():
    if request.method == 'GET':
        return render_template('login.html', menu=get_menu())
    
    # 로그인 확인
    userid = request.form.get('userid')
    password = request.form.get('password')
    
    users = [m for m in members if m['id'] == userid and m['pw'] == password]
    if len(users) == 0:
        # return '로그인 실패'
        return render_template('login.html', menu=get_menu(), msg='로그인에 실패했습니다.')
    else:
        # '로그인 성공'
        session['user'] = users[0]
        return redirect('/')

@app.route('/logout')
def logout():
    session.pop('user')
    # delete session['user']
    return redirect('/')

        
if __name__ == '__main__':
    app.run()