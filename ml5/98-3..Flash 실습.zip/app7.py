# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습7
# http://localhost:5000/  
# 1. index1.html, template2.html 파일을 views 폴더에 복사해 놓아야 함
# 2. 그리고 미리 template2.html 파일 웹브라우져에서 미리 보고 포맷이 어떻게 되어 있는지 확인

# content 폴더에서 파일에서 읽어오기



from flask import Flask, abort

app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True
    
def get_template(filename):
    with open(f'views/{filename}', 'r', encoding='utf-8') as f:
        template = f.read()
    return template
    

#  get_menu 실행하면 아래와 같이 나오게 만듬
#     <li><a href="/html/">HTML</a></li>
#     <li><a href="/css/">CSS</a></li>
#     <li><a href="/javascript/">JavaScript</a></li>
    
def get_menu():
    import os
    menus = [f'<li><a href="/{file}">{file.upper()}</a></li>' 
             for file in os.listdir('content1') if '.' not in file]
    return '\n'.join(menus)


@app.route('/')
def index():
    return get_template('index1.html').format(menu=get_menu())


@app.route('/<title>')
@app.route('/<title>/')
def page(title):
    import os
    if not os.path.isfile(f'content1/{title}'):
        return abort(404)
        
    with open(f'content1/{title}', 'r', encoding='utf8') as f:
        content = f.read()
    return get_template('template2.html').format(title=title, content=content, menu=get_menu())


@app.route('/stars/<num>')
def stars(num):
    stars = ["*" * (i + 1) for i in range(int(num))]
    return "<br>".join(stars)


@app.route('/daum')
@app.route('/daum/')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text


if __name__ == '__main__':
    app.run()