# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습6
# template.html 파일을 views 폴더에 미리 복사해 놓아야 함.

# http://localhost:5000/  

# template & 변수 활용하여 url path 지정
# route에 변수를 지정하여 넘겨 줄수 있음 : '/<title>' , '/stars/<num>'

# content 폴더 만들고 그아래 html, css, javascript 폴더 3개를 만들어야 함

# 미리 template1.html 파일을 views 폴더에 복사해 놓아야 함
# 그리고 미리 template1.html 파일 웹브라우져에서 미리 보고 포맷이 어떻게 되어 있는지 확인
# 여기서 매뉴 추가해 보겠음



from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/daum')
def daum():
    import requests
    res = requests.get('https://daum.net')
    return res.text
    
def get_template(filename):
    with open(f'views/{filename}', 'r', encoding='utf-8') as f:
        template = f.read()
    return template
    

#  get_menu 실행하면 아래와 같이 나오게 만듬
#     <li><a href="/html/">HTML</a></li>
#     <li><a href="/css/">CSS</a></li>
#     <li><a href="/javascript/">JavaScript</a></li>
    
def get_menu():
    import os
    menus = [f'<li><a href="/{file}">{file.upper()}</a></li>' 
             for file in os.listdir('content') if '.' not in file]
    return '\n'.join(menus)


@app.route('/')
def index():
    return get_template('index.html')

contents = {
    'html': 'html is ...',
    'css': 'css is ...',
    'javascript': 'javascript is ...'
}

@app.route('/<title>/')
def page(title):
    return get_template('template1.html').format(title, contents.get(title), get_menu())

@app.route('/stars/<num>')
def stars(num):
    stars = ["*" * (i + 1) for i in range(int(num))]
    return "<br>".join(stars)

if __name__ == '__main__':
    app.run()