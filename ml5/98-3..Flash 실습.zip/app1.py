# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습1
# index.html 파일 만들고 아무 내용 채우거나 index.html 파일 복사해도 됨

# 도스창에서 python app1.py 이런식으로 실행하기
# http://localhost:5000/  접속하기
# http://localhost:5000/html  , http://localhost:5000/css , http://localhost:5000/javascript

from flask import Flask
app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True

@app.route('/')
def hello_world():
    with open('index.html', 'r', encoding='utf-8') as f:
        index = f.read()
    return index

@app.route('/html/')
def html():
    return 'Html is ...'

@app.route('/css/')
def css():
    return 'Css is ...'

@app.route('/javascript/')
def javascript():
    return 'javascript is ...'


if __name__ == '__main__':
    app.run()