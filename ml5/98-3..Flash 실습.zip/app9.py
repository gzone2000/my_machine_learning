# Flask 사이트 : https://flask-docs-kr.readthedocs.io/ko/latest/index.html

# Flash 실습9
# 1주부터 num주까지 다음 영화 목록 추출
# http://127.0.0.1:5000/movies/1


from flask import Flask, abort, render_template

app = Flask(__name__)
app.config['ENV'] = 'development'
app.config['DEBUG'] = True


@app.route('/movies/<num>')
def movies(num):
    import re, requests, bs4, datetime

    def get_movies(week_date=''):
        url = 'https://movie.daum.net/boxoffice/weekly'
        query = {'startDate': week_date}
        res = requests.get(url, params=query)
        soup = bs4.BeautifulSoup(res.content, 'html.parser')

        movies = []
        for tag in soup.select('.list_movieranking > li')[:14]:
            title = tag.strong.a.get_text()
            rank = tag.select('.rank_num')[0].text
            open_day = tag.select('.txt_num')[0].text
            attendance = tag.select('.info_txt')[1].text
            attendance = re.sub(r'[^0-9]','',attendance)

            #print(title, rank, open_day, attendance)

            getter = dict(title = title, 
                          rank = rank,
                          open_day = open_day,
                          attendance = attendance
                         )
            movies.append(getter)

        return movies
    
    weeks = [datetime.date.today() - datetime.timedelta(days=i*7) 
             for i in range(int(num))]
    weeks_best = [get_movies(w.strftime('%Y%m%d')) for w in weeks]
    
    return render_template('movies.html', weeks_best=weeks_best)

if __name__ == '__main__':
    app.run()